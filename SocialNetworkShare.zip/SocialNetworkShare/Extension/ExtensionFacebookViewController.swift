//
//  ExtensionFacebookViewController.swift
//  SocialNetworkShare
//
//  Created by Sierra 4 on 24/04/17.
//  Copyright © 2017 code.brew. All rights reserved.
//

import Foundation
import FBSDKShareKit
import FBSDKLoginKit
import FBSDKCoreKit

extension FacebookViewController
{
    func facebookLogin()
    {
        if((FBSDKAccessToken.current()) != nil)
        {
            print("You have already login")
        }
        else
        {
            let login = FBSDKLoginManager()
            login.loginBehavior = FBSDKLoginBehavior.browser
            let permissions = ["public_profile", "email", "user_friends"]
            login.logIn(withReadPermissions:permissions, from: self, handler: {(result, error) -> Void in
                if error != nil
                {
                    print(error?.localizedDescription ?? "nil")
                }
                else if (result?.isCancelled)!
                {
                    
                }
                else
                {
                    print(result.debugDescription)
                }
            })
        }
    }
    func facbookShare()
    {
        if FBSDKAccessToken.current().hasGranted("publish_actions")
        {
            self.shareData()
        }
        else
        {
            let login: FBSDKLoginManager = FBSDKLoginManager()
            login.logIn(withPublishPermissions: ["publish_actions"], from: self, handler: { (result, error) in
                if (error != nil) {
                    print(error?.localizedDescription ?? "nil")
                } else if (result?.isCancelled)! {
                    
                } else if (result?.grantedPermissions.contains("publish_actions"))! {
                    self.shareData()
                }
            })
            
        }
    }
    func shareData()
    {
        FBSDKGraphRequest(graphPath: "me/feed", parameters: ["message": "Testing post ... please dont comment or like on this post Thank you !!" , "link" : "https://storage.googleapis.com/swimpy/profilePic_1492078974913.jpg"], httpMethod: "POST").start(completionHandler: {(connection, result, error) -> Void in
            if error == nil {
                print("your post is shared successfully !!")
            }
            else{
                print("Something went wrong")
            }
        })
    }
    
    func getFbInfo()
    {
        let graphRequest:FBSDKGraphRequest = FBSDKGraphRequest(graphPath: "me", parameters: ["fields":"first_name,email, picture.type(large)"])
        
        graphRequest.start(completionHandler: { (connection, result, error) -> Void in
            
            if ((error) != nil)
            {
                print("Error: \(error)")
            }
            else
            {
                let data:[String:AnyObject] = result as! [String : AnyObject]
                print("DATA:",data)
                self.getFbInfo()
            }
        })
    }

}
