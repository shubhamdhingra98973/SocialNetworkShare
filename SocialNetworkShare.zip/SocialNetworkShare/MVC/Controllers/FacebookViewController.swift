//
//  FacebookViewController.swift
//  SocialNetworkShare
//
//  Created by Sierra 4 on 24/04/17.
//  Copyright © 2017 code.brew. All rights reserved.
//

import UIKit
import FBSDKLoginKit

class FacebookViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    @IBAction func btnFacebookShare(_ sender: UIButton)
    {
        if((FBSDKAccessToken.current()) != nil)
        {
         facbookShare()
        }

    }
    
    @IBAction func btnFacbookLogin(_ sender: UIButton)
    {
        facebookLogin()
    }
    @IBAction func btnBackAction(_ sender: UIButton) {
      
        _ = self.navigationController?.popViewController(animated: true)
    }
    

}
